{
    "name": "EEZEE Sale Order Extension",
    "version": "1.0",
    "depends": ["sale_management", "stock"],
    "author": "You",
    "category": "Sales",
    "data": [
        "views/sale_order_views.xml",
    ],
    "installable": True,
}
